//! Uçtan uca M0 kapısı: gerçek binary'yi stdio üzerinden, eski (initialize) el sıkışmasıyla sürer.
//!
//! `server/discover` akışı için ayrı fixture eklenecek (bkz. README, "M0 kalan işler").

use std::io::{BufRead, BufReader, Write};
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::mpsc::{self, Receiver};
use std::thread;
use std::time::Duration;

use cvm_core::envelope::ResponseEnvelope;
use cvm_core::validate::validate;
use serde_json::{json, Value};

struct Client {
    child: Child,
    stdin: ChildStdin,
    rx: Receiver<Value>,
    next_id: u64,
}

impl Client {
    fn spawn(envs: &[(&str, &str)]) -> Self {
        let mut cmd = Command::new(env!("CARGO_BIN_EXE_cvm-mcp"));
        cmd.stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null());
        for (k, v) in envs {
            cmd.env(k, v);
        }
        let mut child = cmd.spawn().expect("spawn cvm-mcp");
        let stdin = child.stdin.take().expect("stdin");
        let stdout = child.stdout.take().expect("stdout");

        let (tx, rx) = mpsc::channel();
        thread::spawn(move || {
            for line in BufReader::new(stdout).lines().map_while(Result::ok) {
                if let Ok(v) = serde_json::from_str::<Value>(&line) {
                    if tx.send(v).is_err() {
                        break;
                    }
                }
            }
        });

        Client {
            child,
            stdin,
            rx,
            next_id: 1,
        }
    }

    fn send(&mut self, msg: &Value) {
        writeln!(self.stdin, "{msg}").expect("write to server");
        self.stdin.flush().expect("flush");
    }

    fn request(&mut self, method: &str, params: Value) -> Value {
        let id = self.next_id;
        self.next_id += 1;
        self.send(&json!({"jsonrpc": "2.0", "id": id, "method": method, "params": params}));
        loop {
            let msg = self
                .rx
                .recv_timeout(Duration::from_secs(10))
                .expect("timed out waiting for a server response");
            if msg.get("id") == Some(&json!(id)) {
                return msg;
            }
        }
    }

    fn notify(&mut self, method: &str) {
        self.send(&json!({"jsonrpc": "2.0", "method": method}));
    }

    fn handshake(&mut self) -> Value {
        let init = self.request(
            "initialize",
            json!({
                "protocolVersion": "2025-11-25",
                "capabilities": {},
                "clientInfo": {"name": "cvm-fixture-client", "version": "0.0.0"}
            }),
        );
        self.notify("notifications/initialized");
        init
    }

    fn search(&mut self, query: &str) -> Value {
        self.request(
            "tools/call",
            json!({"name": "search_knowledge", "arguments": {"query": query}}),
        )
    }
}

impl Drop for Client {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

#[test]
fn fixture_query_is_answered_with_a_schema_valid_citation() {
    let mut c = Client::spawn(&[]);
    let init = c.handshake();
    assert_eq!(init["result"]["serverInfo"]["name"], "cassandra-viam-mcp");

    let resp = c.search("What is hypothesis 027 about context compaction?");
    let result = &resp["result"];
    assert_ne!(result["isError"], json!(true), "{resp}");

    let text = result["content"][0]["text"].as_str().expect("text content");
    let env: ResponseEnvelope = serde_json::from_str(text).expect("cvm.v1 envelope");
    assert!(validate(&env).is_empty(), "{:?}", validate(&env));

    let top = &env.results[0];
    assert_eq!(top.work_id.as_str(), "work:cassandra-synthetic/hypothesis-027");
    assert!(!top.citations.is_empty());
}

#[test]
fn empty_query_is_a_correctable_tool_error() {
    let mut c = Client::spawn(&[]);
    c.handshake();
    let resp = c.search("   ");
    assert_eq!(resp["result"]["isError"], json!(true), "{resp}");
}

#[test]
fn shared_scope_does_not_leak_project_evidence_but_project_scope_sees_it() {
    let query = "private customer dataset confidential";

    let mut shared = Client::spawn(&[]);
    shared.handshake();
    let text = shared.search(query).to_string();
    assert!(!text.contains("proj-alpha"), "leak: {text}");

    let mut project = Client::spawn(&[("CVM_SCOPE_PROJECT", "proj-alpha")]);
    project.handshake();
    let text = project.search(query).to_string();
    assert!(text.contains("work:proj-alpha-private/note-001"), "{text}");
}
