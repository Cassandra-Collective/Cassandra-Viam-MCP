//! MCP adaptörü (stdio). SDK'ya bağlı TEK dosya burasıdır; alan mantığı `cvm-core`'dadır.
//!
//! M0 çıkış kriteri: sabitlenmiş tek bir Rust MCP süreci, bir fixture sorgusunu
//! şemaya uygun atıfla yanıtlar.

use std::sync::Arc;

use cvm_core::fixtures::Corpus;
use cvm_core::search::{search, Scope};
use cvm_core::validate::validate;
use rmcp::{
    handler::server::wrapper::Parameters,
    model::{CallToolResult, ContentBlock},
    schemars, tool, tool_handler, tool_router,
    transport::stdio,
    ErrorData as McpError, ServerHandler, ServiceExt,
};
use tracing_subscriber::EnvFilter;

#[derive(Debug, serde::Deserialize, schemars::JsonSchema)]
struct SearchArgs {
    /// Free-text question or keywords, e.g. "What was decided in ADR 0019?"
    query: String,
    /// Maximum number of results (1-20, default 5).
    limit: Option<u32>,
}

#[derive(Clone)]
struct CassandraServer {
    corpus: Arc<Corpus>,
    /// Kapsam sunucu tarafında belirlenir (M7'de kimlik bilgisinden). Araç argümanı DEĞİLDİR.
    scope: Scope,
}

#[tool_router]
impl CassandraServer {
    #[tool(
        description = "Search the published Cassandra knowledge snapshot. Every result carries \
                       citations (source, immutable revision, exact locator, license). \
                       Returns a JSON envelope with schema_version \"cvm.v1\"."
    )]
    async fn search_knowledge(
        &self,
        Parameters(args): Parameters<SearchArgs>,
    ) -> Result<CallToolResult, McpError> {
        let query = args.query.trim();
        if query.is_empty() {
            // Düzeltilebilir hata: araç sonucu (isError), protokol hatası değil.
            return Ok(CallToolResult::error(vec![ContentBlock::text(
                "query must not be empty",
            )]));
        }

        let limit = args.limit.unwrap_or(5) as usize;
        let envelope = search(&self.corpus, &self.scope, query, limit);

        // Sözleşmeyi ihlal eden zarf istemciye gitmez; bu bir sunucu hatasıdır.
        let problems = validate(&envelope);
        if !problems.is_empty() {
            tracing::error!(?problems, "response envelope violates cvm.v1");
            return Err(McpError::internal_error(
                "response envelope failed validation",
                None,
            ));
        }

        let json = serde_json::to_string(&envelope)
            .map_err(|e| McpError::internal_error(e.to_string(), None))?;
        Ok(CallToolResult::success(vec![ContentBlock::text(json)]))
    }
}

#[tool_handler(
    name = "cassandra-viam-mcp",
    version = "0.0.1",
    instructions = "Read-only knowledge service. Use search_knowledge and cite the returned locators."
)]
impl ServerHandler for CassandraServer {}

fn scope_from_env() -> Scope {
    match std::env::var("CVM_SCOPE_PROJECT") {
        Ok(p) if !p.trim().is_empty() => Scope::Project(p.trim().to_owned()),
        _ => Scope::SharedOnly,
    }
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // stdio taşımasında stdout JSON-RPC içindir: günlükler yalnızca stderr'e gider.
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env().add_directive(tracing::Level::INFO.into()))
        .with_writer(std::io::stderr)
        .with_ansi(false)
        .init();

    let corpus = Corpus::load_embedded().map_err(|e| anyhow::anyhow!("fixture integrity: {e}"))?;
    let scope = scope_from_env();
    tracing::info!(fixture = %corpus.fixture_version, ?scope, "starting cassandra-viam-mcp");

    let server = CassandraServer {
        corpus: Arc::new(corpus),
        scope,
    };
    let service = server.serve(stdio()).await?;
    service.waiting().await?;
    Ok(())
}
