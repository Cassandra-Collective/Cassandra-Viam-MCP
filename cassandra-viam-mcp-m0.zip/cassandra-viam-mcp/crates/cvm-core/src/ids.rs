//! v1 kimlik kuralları (donmuş).
//!
//! * `SourceId`   : `src:<slug>`
//! * `WorkId`     : `work:<source-slug>/<work-slug>`
//! * `RevisionId` : `rev:<source-slug>/<work-slug>@<16 hex>`
//!   (hex = içeriğin SHA-256 özetinin ilk 8 baytı; revision'lar değişmezdir)
//!
//! slug: `[a-z0-9][a-z0-9._-]{0,63}`

use std::fmt;

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum IdError {
    WrongPrefix(&'static str),
    BadSlug(String),
    BadDigest(String),
    Malformed(String),
}

impl fmt::Display for IdError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            IdError::WrongPrefix(p) => write!(f, "id must start with `{p}`"),
            IdError::BadSlug(s) => write!(f, "invalid slug `{s}`"),
            IdError::BadDigest(s) => write!(f, "invalid revision digest `{s}`"),
            IdError::Malformed(s) => write!(f, "malformed id `{s}`"),
        }
    }
}

impl std::error::Error for IdError {}

const SLUG_MAX: usize = 64;

fn check_slug(s: &str) -> Result<(), IdError> {
    let mut chars = s.chars();
    let first_ok = matches!(chars.next(), Some(c) if c.is_ascii_lowercase() || c.is_ascii_digit());
    let rest_ok = chars
        .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || matches!(c, '.' | '_' | '-'));
    if first_ok && rest_ok && s.len() <= SLUG_MAX {
        Ok(())
    } else {
        Err(IdError::BadSlug(s.to_owned()))
    }
}

/// `<slug>/<slug>` çiftini doğrular.
fn check_pair(s: &str) -> Result<(), IdError> {
    let (a, b) = s
        .split_once('/')
        .ok_or_else(|| IdError::Malformed(s.to_owned()))?;
    check_slug(a)?;
    check_slug(b)
}

macro_rules! id_type {
    ($name:ident) => {
        #[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
        #[serde(try_from = "String", into = "String")]
        pub struct $name(String);

        impl $name {
            pub fn as_str(&self) -> &str {
                &self.0
            }
        }

        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                f.write_str(&self.0)
            }
        }

        impl From<$name> for String {
            fn from(v: $name) -> String {
                v.0
            }
        }

        impl TryFrom<String> for $name {
            type Error = IdError;
            fn try_from(s: String) -> Result<Self, IdError> {
                Self::parse(&s)
            }
        }
    };
}

id_type!(SourceId);
id_type!(WorkId);
id_type!(RevisionId);

impl SourceId {
    pub fn parse(s: &str) -> Result<Self, IdError> {
        let slug = s
            .strip_prefix("src:")
            .ok_or(IdError::WrongPrefix("src:"))?;
        check_slug(slug)?;
        Ok(Self(s.to_owned()))
    }

    pub fn slug(&self) -> &str {
        &self.0["src:".len()..]
    }
}

impl WorkId {
    pub fn parse(s: &str) -> Result<Self, IdError> {
        let rest = s
            .strip_prefix("work:")
            .ok_or(IdError::WrongPrefix("work:"))?;
        check_pair(rest)?;
        Ok(Self(s.to_owned()))
    }

    pub fn source_slug(&self) -> &str {
        let rest = &self.0["work:".len()..];
        rest.split('/').next().unwrap_or(rest)
    }
}

impl RevisionId {
    pub fn parse(s: &str) -> Result<Self, IdError> {
        let rest = s
            .strip_prefix("rev:")
            .ok_or(IdError::WrongPrefix("rev:"))?;
        let (pair, digest) = rest
            .rsplit_once('@')
            .ok_or_else(|| IdError::Malformed(s.to_owned()))?;
        check_pair(pair)?;
        if digest.len() != 16 || !digest.chars().all(|c| matches!(c, '0'..='9' | 'a'..='f')) {
            return Err(IdError::BadDigest(digest.to_owned()));
        }
        Ok(Self(s.to_owned()))
    }

    /// İçerikten türetilen değişmez revision kimliği.
    pub fn from_content(work: &WorkId, content: &[u8]) -> Self {
        let digest = Sha256::digest(content);
        let hex: String = digest.iter().take(8).map(|b| format!("{b:02x}")).collect();
        Self(format!("rev:{}@{hex}", &work.as_str()["work:".len()..]))
    }

    pub fn work_id(&self) -> WorkId {
        let rest = &self.0["rev:".len()..];
        let pair = rest.rsplit_once('@').map(|(p, _)| p).unwrap_or(rest);
        WorkId(format!("work:{pair}"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_ids_roundtrip() {
        assert!(SourceId::parse("src:cassandra-synthetic").is_ok());
        assert!(WorkId::parse("work:arxiv-synthetic/2699.00001").is_ok());
        let rev = RevisionId::parse("rev:s/w@2cf24dba5fb0a30e").unwrap();
        assert_eq!(rev.work_id().as_str(), "work:s/w");
    }

    #[test]
    fn invalid_ids_are_rejected() {
        assert!(SourceId::parse("cassandra").is_err());
        assert!(SourceId::parse("src:Upper").is_err());
        assert!(SourceId::parse("src:").is_err());
        assert!(WorkId::parse("work:only-one-part").is_err());
        assert!(WorkId::parse("work:a/b/c").is_err());
        assert!(RevisionId::parse("rev:s/w@short").is_err());
        assert!(RevisionId::parse("rev:s/w@2CF24DBA5FB0A30E").is_err());
    }

    #[test]
    fn digest_is_stable() {
        // sha256("hello") = 2cf24dba5fb0a30e...
        let w = WorkId::parse("work:s/w").unwrap();
        assert_eq!(
            RevisionId::from_content(&w, b"hello").as_str(),
            "rev:s/w@2cf24dba5fb0a30e"
        );
    }

    #[test]
    fn serde_enforces_the_grammar() {
        assert!(serde_json::from_str::<SourceId>("\"src:ok\"").is_ok());
        assert!(serde_json::from_str::<SourceId>("\"SRC:Bad\"").is_err());
        assert_eq!(
            serde_json::to_string(&SourceId::parse("src:ok").unwrap()).unwrap(),
            "\"src:ok\""
        );
    }
}
