//! v1 zarf sözleşmesinin çalışma zamanı doğrulaması.
//! Sunucu, sözleşmeyi ihlal eden bir zarfı ASLA istemciye göndermez.

use crate::envelope::{Locator, ResponseEnvelope, ReviewState, SCHEMA_VERSION};

/// Boş liste = geçerli.
pub fn validate(env: &ResponseEnvelope) -> Vec<String> {
    let mut errs = Vec::new();

    if env.schema_version != SCHEMA_VERSION {
        errs.push(format!(
            "schema_version must be {SCHEMA_VERSION}, got {}",
            env.schema_version
        ));
    }

    for (i, r) in env.results.iter().enumerate() {
        let at = format!("results[{i}] ({})", r.work_id);

        if r.citations.is_empty() {
            errs.push(format!("{at}: result without citations"));
        }
        if r.review_state == ReviewState::Reviewed
            && r.citations.iter().any(|c| c.dates.reviewed_at.is_none())
        {
            errs.push(format!("{at}: reviewed result without reviewed_at"));
        }

        for (j, c) in r.citations.iter().enumerate() {
            let at = format!("{at}.citations[{j}]");
            if c.work_id != r.work_id {
                errs.push(format!("{at}: citation work_id differs from result"));
            }
            if c.revision_id.work_id() != c.work_id {
                errs.push(format!("{at}: revision_id does not belong to work_id"));
            }
            if c.work_id.source_slug() != c.source_id.slug() {
                errs.push(format!("{at}: work_id does not belong to source_id"));
            }
            if c.license.trim().is_empty() {
                errs.push(format!("{at}: empty license"));
            }
            if c.attribution.trim().is_empty() {
                errs.push(format!("{at}: empty attribution"));
            }
            check_locator(&c.locator, &at, &mut errs);
        }
    }
    errs
}

fn check_locator(loc: &Locator, at: &str, errs: &mut Vec<String>) {
    match loc {
        Locator::Git {
            repo,
            commit,
            path,
            line_start,
            line_end,
            ..
        } => {
            if !repo.contains('/') {
                errs.push(format!("{at}: repo must be owner/repo"));
            }
            if commit.len() != 40 || !commit.chars().all(|c| matches!(c, '0'..='9' | 'a'..='f')) {
                errs.push(format!("{at}: commit must be a 40-char lowercase hex sha"));
            }
            if path.is_empty() || path.starts_with('/') || path.split('/').any(|p| p == "..") {
                errs.push(format!("{at}: invalid path `{path}`"));
            }
            match (line_start, line_end) {
                (Some(a), Some(b)) if *a == 0 || *a > *b => {
                    errs.push(format!("{at}: invalid line range {a}..{b}"));
                }
                (Some(_), None) | (None, Some(_)) => {
                    errs.push(format!("{at}: line_start and line_end must come together"));
                }
                _ => {}
            }
        }
        Locator::External {
            external_id, url, ..
        } => {
            if external_id.trim().is_empty() {
                errs.push(format!("{at}: empty external_id"));
            }
            if !url.starts_with("https://") {
                errs.push(format!("{at}: url must be https"));
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::fixtures::Corpus;
    use crate::search::{search, Scope};

    fn valid_envelope() -> ResponseEnvelope {
        let corpus = Corpus::load_embedded().unwrap();
        search(&corpus, &Scope::SharedOnly, "context compaction hypothesis", 5)
    }

    #[test]
    fn real_search_output_is_valid() {
        assert!(validate(&valid_envelope()).is_empty());
    }

    #[test]
    fn missing_citations_are_rejected() {
        let mut env = valid_envelope();
        env.results[0].citations.clear();
        assert!(validate(&env).iter().any(|e| e.contains("without citations")));
    }

    #[test]
    fn bad_commit_and_line_range_are_rejected() {
        let mut env = valid_envelope();
        if let Locator::Git {
            commit,
            line_start,
            line_end,
            ..
        } = &mut env.results[0].citations[0].locator
        {
            *commit = "not-a-commit".into();
            *line_start = Some(5);
            *line_end = Some(2);
        }
        let errs = validate(&env);
        assert!(errs.iter().any(|e| e.contains("commit")));
        assert!(errs.iter().any(|e| e.contains("line range")));
    }

    #[test]
    fn reviewed_result_needs_reviewed_at() {
        let mut env = valid_envelope();
        env.results[0].review_state = ReviewState::Reviewed;
        env.results[0].citations[0].dates.reviewed_at = None;
        assert!(validate(&env).iter().any(|e| e.contains("reviewed_at")));
    }

    #[test]
    fn wrong_schema_version_is_rejected() {
        let mut env = valid_envelope();
        env.schema_version = "cvm.v0".into();
        assert!(!validate(&env).is_empty());
    }
}
