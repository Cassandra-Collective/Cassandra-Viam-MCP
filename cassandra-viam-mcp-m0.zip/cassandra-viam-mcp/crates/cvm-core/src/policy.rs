//! Onboarding path allowlist'i ve atıf eşlemesi (M0: onaylanacak veri; M2: uygulanacak yer).

use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
pub struct PathRule {
    pub prefix: String,
    pub extensions: Vec<String>,
    pub attribution: String,
    pub license: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct PathPolicy {
    pub max_bytes: u64,
    pub rules: Vec<PathRule>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Deny {
    Empty,
    Absolute,
    Malformed,
    DotGit,
    Symlink,
    TooLarge,
    OutOfScope,
    Extension,
}

impl PathPolicy {
    pub fn embedded() -> Result<Self, String> {
        serde_json::from_str(include_str!("../../../fixtures/m0/path_policy.json"))
            .map_err(|e| format!("path_policy.json: {e}"))
    }

    /// Yolu kurallara göre çözer. Eşleşen kural, atıf ve lisansı da taşır.
    pub fn resolve(&self, path: &str, size: u64, is_symlink: bool) -> Result<&PathRule, Deny> {
        if path.is_empty() {
            return Err(Deny::Empty);
        }
        if path.starts_with('/') {
            return Err(Deny::Absolute);
        }
        if path.contains('\\') {
            return Err(Deny::Malformed);
        }
        for component in path.split('/') {
            match component {
                "" | "." | ".." => return Err(Deny::Malformed),
                ".git" => return Err(Deny::DotGit),
                _ => {}
            }
        }
        if is_symlink {
            return Err(Deny::Symlink);
        }
        if size > self.max_bytes {
            return Err(Deny::TooLarge);
        }
        let rule = self
            .rules
            .iter()
            .find(|r| path.starts_with(&r.prefix))
            .ok_or(Deny::OutOfScope)?;
        let ext_ok = path
            .rsplit_once('.')
            .map(|(_, ext)| rule.extensions.iter().any(|e| e == ext))
            .unwrap_or(false);
        if ext_ok {
            Ok(rule)
        } else {
            Err(Deny::Extension)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn policy() -> PathPolicy {
        PathPolicy::embedded().unwrap()
    }

    #[test]
    fn allows_in_scope_markdown() {
        assert!(policy().resolve("docs/adr/0019-x.md", 100, false).is_ok());
    }

    #[test]
    fn rejects_everything_else() {
        let p = policy();
        assert_eq!(p.resolve("", 1, false), Err(Deny::Empty));
        assert_eq!(p.resolve("/etc/passwd", 1, false), Err(Deny::Absolute));
        assert_eq!(p.resolve("docs/../secret.md", 1, false), Err(Deny::Malformed));
        assert_eq!(p.resolve("docs\\adr\\x.md", 1, false), Err(Deny::Malformed));
        assert_eq!(p.resolve("docs/adr/.git/config", 1, false), Err(Deny::DotGit));
        assert_eq!(p.resolve("docs/adr/x.md", 1, true), Err(Deny::Symlink));
        assert_eq!(p.resolve("docs/adr/x.md", u64::MAX, false), Err(Deny::TooLarge));
        assert_eq!(p.resolve("src/main.rs", 1, false), Err(Deny::OutOfScope));
        assert_eq!(p.resolve("docs/adr/x.exe", 1, false), Err(Deny::Extension));
        assert_eq!(p.resolve("docs/adr/noext", 1, false), Err(Deny::Extension));
    }
}
