//! M0 kapı kontrolleri: izleme konusu kataloğu ve R1–R8 eşlemesi.
//! `fixtures/m0/watch_topics.json` şimdilik PLACEHOLDER'dır; gerçek katalog ARCHITECTURE.md'den gelmelidir.

use serde::Deserialize;

use crate::ids::WorkId;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum QuestionKind {
    Single,
    InternalExternal,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Question {
    pub id: String,
    pub kind: QuestionKind,
    pub text: String,
    pub expected_answer: String,
    pub expected_work_ids: Vec<WorkId>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct WatchTopic {
    pub id: String,
    pub title: String,
    #[serde(default)]
    pub placeholder: bool,
    pub questions: Vec<Question>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Check {
    pub kind: String,
    #[serde(rename = "ref")]
    pub reference: String,
    pub status: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Requirement {
    pub id: String,
    pub title: String,
    pub milestones: Vec<String>,
    pub check: Check,
}

pub fn watch_topics() -> Result<Vec<WatchTopic>, String> {
    serde_json::from_str(include_str!("../../../fixtures/m0/watch_topics.json"))
        .map_err(|e| format!("watch_topics.json: {e}"))
}

pub fn requirements() -> Result<Vec<Requirement>, String> {
    serde_json::from_str(include_str!("../../../fixtures/m0/requirements.json"))
        .map_err(|e| format!("requirements.json: {e}"))
}

/// Her konu için ≥2 soru, ≥1 dahili-harici kanıt sorusu; her soruda beklenen cevap ve kaynak.
pub fn check_watch_topics(topics: &[WatchTopic]) -> Vec<String> {
    let mut errs = Vec::new();
    if topics.is_empty() {
        errs.push("catalog has no topics".to_owned());
    }
    for t in topics {
        if t.questions.len() < 2 {
            errs.push(format!("topic {}: needs at least 2 questions", t.id));
        }
        if !t
            .questions
            .iter()
            .any(|q| q.kind == QuestionKind::InternalExternal)
        {
            errs.push(format!(
                "topic {}: needs at least 1 internal-external evidence question",
                t.id
            ));
        }
        for q in &t.questions {
            if q.expected_answer.trim().is_empty() || q.expected_work_ids.is_empty() {
                errs.push(format!("question {}: missing expected answer or works", q.id));
            }
        }
    }
    errs
}

/// R1–R8'in her biri tam bir kez, bir milestone'a ve bir fixture/operasyonel kontrole bağlı olmalı.
pub fn check_requirements(reqs: &[Requirement]) -> Vec<String> {
    let mut errs = Vec::new();
    for n in 1..=8 {
        let id = format!("R{n}");
        match reqs.iter().filter(|r| r.id == id).count() {
            1 => {}
            c => errs.push(format!("{id}: expected exactly one entry, found {c}")),
        }
    }
    for r in reqs {
        if r.milestones.is_empty() || r.milestones.iter().any(|m| !is_milestone(m)) {
            errs.push(format!("{}: invalid milestones {:?}", r.id, r.milestones));
        }
        if !matches!(r.check.kind.as_str(), "fixture" | "operational") {
            errs.push(format!("{}: check kind must be fixture|operational", r.id));
        }
        if r.check.reference.trim().is_empty() {
            errs.push(format!("{}: empty check reference", r.id));
        }
        if !matches!(r.check.status.as_str(), "present" | "planned") {
            errs.push(format!("{}: check status must be present|planned", r.id));
        }
    }
    errs
}

fn is_milestone(m: &str) -> bool {
    m.len() == 2 && m.starts_with('M') && m.as_bytes()[1].is_ascii_digit()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn embedded_catalog_satisfies_the_m0_rules() {
        let errs = check_watch_topics(&watch_topics().unwrap());
        assert!(errs.is_empty(), "{errs:?}");
    }

    #[test]
    fn embedded_requirements_cover_r1_to_r8() {
        let errs = check_requirements(&requirements().unwrap());
        assert!(errs.is_empty(), "{errs:?}");
    }

    #[test]
    fn topic_without_internal_external_question_fails() {
        let mut topics = watch_topics().unwrap();
        topics[0]
            .questions
            .retain(|q| q.kind != QuestionKind::InternalExternal);
        assert!(!check_watch_topics(&topics).is_empty());
    }

    #[test]
    fn missing_requirement_fails() {
        let mut reqs = requirements().unwrap();
        reqs.retain(|r| r.id != "R5");
        assert!(!check_requirements(&reqs).is_empty());
    }
}
