//! Fixture korpusu üzerinde kapsamlı (scope) arama. Eşleştirme basit terim örtüşmesidir;
//! M1'de FTS5 ile değişecek, zarf ve kapsam kuralları aynı kalacaktır.

use std::collections::HashSet;

use crate::envelope::{
    Citation, Coverage, Freshness, Locator, ResponseEnvelope, ResultItem, SourceCoverage, Status,
    Visibility, SCHEMA_VERSION,
};
use crate::fixtures::{Corpus, ItemRecord};

/// İstek kapsamı. Sunucu tarafında kimlik bilgisinden türetilir; istemci argümanından ASLA.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Scope {
    SharedOnly,
    Project(String),
}

impl Scope {
    pub fn can_see(&self, v: &Visibility) -> bool {
        match (self, v) {
            (_, Visibility::Shared) => true,
            (Scope::Project(mine), Visibility::Project(theirs)) => mine == theirs,
            (Scope::SharedOnly, Visibility::Project(_)) => false,
        }
    }
}

fn tokens(s: &str) -> HashSet<String> {
    s.split(|c: char| !c.is_alphanumeric())
        .filter(|t| t.chars().count() >= 2)
        .map(str::to_lowercase)
        .collect()
}

fn score(item: &ItemRecord, q: &HashSet<String>) -> u32 {
    let title = tokens(&item.title);
    let body = tokens(&item.content);
    q.iter()
        .map(|t| u32::from(title.contains(t)) * 2 + u32::from(body.contains(t)))
        .sum::<u32>()
}

/// En çok sorgu terimi içeren satır (1 tabanlı) ve kısaltılmış metni.
fn best_line(content: &str, q: &HashSet<String>) -> (u32, String) {
    let mut best_matches = 0usize;
    let mut best_index = 0usize;
    for (i, line) in content.lines().enumerate() {
        let m = tokens(line).intersection(q).count();
        if m > best_matches {
            best_matches = m;
            best_index = i;
        }
    }
    let line = content.lines().nth(best_index).unwrap_or("");
    let snippet: String = line.trim().chars().take(240).collect();
    (best_index as u32 + 1, snippet)
}

pub fn search(corpus: &Corpus, scope: &Scope, query: &str, limit: usize) -> ResponseEnvelope {
    let q = tokens(query);
    let limit = limit.clamp(1, 20);

    // Yetki kapsamı eşleştirmeden ÖNCE uygulanır: görünmeyen kayıt skorlanmaz,
    // sayılmaz, kapsama listesinde de yer almaz.
    let visible_sources: Vec<_> = corpus
        .sources
        .iter()
        .filter(|s| scope.can_see(&s.visibility))
        .collect();

    let mut hits: Vec<(u32, &ItemRecord)> = corpus
        .items
        .iter()
        .filter(|i| i.current && scope.can_see(&i.visibility))
        .filter(|i| visible_sources.iter().any(|s| s.id == i.source_id))
        .map(|i| (score(i, &q), i))
        .filter(|(s, _)| *s > 0)
        .collect();
    hits.sort_by(|a, b| {
        b.0.cmp(&a.0)
            .then_with(|| a.1.work_id.cmp(&b.1.work_id))
    });
    hits.truncate(limit);

    let results: Vec<ResultItem> = hits
        .into_iter()
        .filter_map(|(score, item)| {
            let src = visible_sources.iter().find(|s| s.id == item.source_id)?;
            let (line_no, snippet) = best_line(&item.content, &q);

            let mut locator = item.locator.clone();
            if let Locator::Git {
                line_start,
                line_end,
                ..
            } = &mut locator
            {
                *line_start = Some(line_no);
                *line_end = Some(line_no);
            }

            Some(ResultItem {
                work_id: item.work_id.clone(),
                kind: item.kind,
                title: item.title.clone(),
                snippet,
                score,
                review_state: item.review_state,
                citations: vec![Citation {
                    source_id: item.source_id.clone(),
                    work_id: item.work_id.clone(),
                    revision_id: item.revision_id.clone(),
                    locator,
                    license: src.license.clone(),
                    attribution: src.attribution.clone(),
                    dates: item.dates.clone(),
                }],
            })
        })
        .collect();

    let sources: Vec<SourceCoverage> = visible_sources
        .iter()
        .map(|s| SourceCoverage {
            source_id: s.id.clone(),
            display_name: s.display_name.clone(),
            freshness: s.freshness,
            last_successful_refresh: s.last_successful_refresh.clone(),
        })
        .collect();

    let status = if sources.iter().any(|s| s.freshness == Freshness::Unavailable) {
        Status::Partial
    } else if sources.iter().any(|s| s.freshness == Freshness::Stale) {
        Status::Stale
    } else {
        Status::Ok
    };

    let mut warnings = Vec::new();
    for s in sources.iter().filter(|s| s.freshness != Freshness::Fresh) {
        warnings.push(format!("source {} is {:?}", s.source_id, s.freshness));
    }
    if results.is_empty() {
        warnings.push("no matching evidence in the published snapshot".to_owned());
    }

    ResponseEnvelope {
        schema_version: SCHEMA_VERSION.to_owned(),
        status,
        query: query.to_owned(),
        results,
        coverage: Coverage {
            published_watermark: corpus.published_watermark.clone(),
            sources,
        },
        warnings,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::catalog;
    use crate::validate::validate;

    fn corpus() -> Corpus {
        Corpus::load_embedded().unwrap()
    }

    #[test]
    fn top_hit_is_the_hypothesis_with_a_valid_line_level_citation() {
        let corpus = corpus();
        let env = search(&corpus, &Scope::SharedOnly, "context compaction hypothesis 027", 5);
        assert_eq!(env.status, Status::Ok);
        assert!(validate(&env).is_empty(), "{:?}", validate(&env));

        let top = &env.results[0];
        assert_eq!(top.work_id.as_str(), "work:cassandra-synthetic/hypothesis-027");
        let cite = &top.citations[0];
        let item = corpus.items.iter().find(|i| i.work_id == top.work_id).unwrap();
        assert_eq!(cite.revision_id, item.revision_id);
        match &cite.locator {
            Locator::Git {
                line_start,
                line_end,
                commit,
                ..
            } => {
                assert_eq!(commit.len(), 40);
                let n = line_start.expect("line_start");
                assert_eq!(*line_end, Some(n));
                assert!(n >= 1 && n <= item.content.lines().count() as u32);
            }
            other => panic!("expected git locator, got {other:?}"),
        }
    }

    #[test]
    fn shared_scope_never_sees_project_evidence() {
        let corpus = corpus();
        let env = search(&corpus, &Scope::SharedOnly, "private customer dataset confidential", 5);
        let json = serde_json::to_string(&env).unwrap();
        assert!(!json.contains("proj-alpha"), "leak: {json}");
        assert!(env
            .coverage
            .sources
            .iter()
            .all(|s| s.source_id.as_str() != "src:proj-alpha-private"));

        let env = search(
            &corpus,
            &Scope::Project("proj-alpha".into()),
            "private customer dataset confidential",
            5,
        );
        assert!(env
            .results
            .iter()
            .any(|r| r.work_id.as_str() == "work:proj-alpha-private/note-001"));
        assert!(validate(&env).is_empty());
    }

    #[test]
    fn another_projects_scope_sees_nothing_private() {
        let env = search(
            &corpus(),
            &Scope::Project("proj-beta".into()),
            "private customer dataset confidential",
            5,
        );
        assert!(!serde_json::to_string(&env).unwrap().contains("proj-alpha"));
    }

    #[test]
    fn only_the_current_revision_is_returned() {
        let corpus = corpus();
        let env = search(&corpus, &Scope::SharedOnly, "compaction preprint", 5);
        let hits: Vec<_> = env
            .results
            .iter()
            .filter(|r| r.work_id.as_str() == "work:arxiv-synthetic/2699.00001")
            .collect();
        assert_eq!(hits.len(), 1);
        match &hits[0].citations[0].locator {
            Locator::External { version, .. } => assert_eq!(version.as_deref(), Some("v2")),
            other => panic!("expected external locator, got {other:?}"),
        }
    }

    #[test]
    fn stale_source_degrades_status_and_warns() {
        let mut corpus = corpus();
        corpus.sources[0].freshness = Freshness::Stale;
        let env = search(&corpus, &Scope::SharedOnly, "context compaction", 5);
        assert_eq!(env.status, Status::Stale);
        assert!(env.warnings.iter().any(|w| w.contains("src:cassandra-synthetic")));

        corpus.sources[1].freshness = Freshness::Unavailable;
        let env = search(&corpus, &Scope::SharedOnly, "context compaction", 5);
        assert_eq!(env.status, Status::Partial);
    }

    #[test]
    fn no_match_is_an_empty_ok_result_with_a_warning() {
        let env = search(&corpus(), &Scope::SharedOnly, "zzzzqqqq", 5);
        assert!(env.results.is_empty());
        assert_eq!(env.status, Status::Ok);
        assert!(!env.warnings.is_empty());
    }

    /// Küçük bir alaka koşumu: katalogdaki her soru için beklenen work ilk 5'te olmalı.
    #[test]
    fn watch_topic_questions_find_their_expected_works_in_top_5() {
        let corpus = corpus();
        for topic in catalog::watch_topics().unwrap() {
            for q in &topic.questions {
                let env = search(&corpus, &Scope::SharedOnly, &q.text, 5);
                for expected in &q.expected_work_ids {
                    assert!(
                        env.results.iter().any(|r| &r.work_id == expected),
                        "{}: expected {expected} in top 5",
                        q.id
                    );
                }
            }
        }
    }
}
