//! Cassandra-Viam-MCP alan çekirdeği (M0).
//!
//! Bu crate MCP SDK'sından bağımsızdır: kimlik kuralları, v1 yanıt zarfı,
//! sentetik fixture korpusu, kapsamlı arama ve zarf doğrulaması burada yaşar.
//! SDK'ya bağlı kod yalnızca `cvm-mcp` içindedir.

pub mod catalog;
pub mod envelope;
pub mod fixtures;
pub mod ids;
pub mod policy;
pub mod search;
pub mod validate;
