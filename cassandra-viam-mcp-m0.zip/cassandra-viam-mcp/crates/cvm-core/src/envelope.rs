//! v1 yanıt zarfı (donmuş). Alan adları ve enum değerleri sözleşmedir;
//! değişiklik yeni bir `schema_version` gerektirir.

use serde::{Deserialize, Serialize};

use crate::ids::{RevisionId, SourceId, WorkId};

pub const SCHEMA_VERSION: &str = "cvm.v1";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Status {
    Ok,
    Partial,
    Stale,
    Unavailable,
    InsufficientEvidence,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WorkKind {
    Hypothesis,
    Stage,
    Adr,
    Preprint,
    Release,
    Note,
}

/// discovered → reviewed → needs_review (M5 iş akışı bu değerleri kullanır).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ReviewState {
    Discovered,
    Reviewed,
    NeedsReview,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Freshness {
    Fresh,
    Stale,
    Unavailable,
}

/// `Shared`: kimliği doğrulanmış her kullanıcıya açık. `Project`: yalnızca o projenin kapsamına.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "scope", content = "project", rename_all = "snake_case")]
pub enum Visibility {
    Shared,
    Project(String),
}

/// Kesin konum: dahili için Git (repo, ref, commit, path, satır), harici için kaynak kimliği + sürüm.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Locator {
    Git {
        repo: String,
        git_ref: String,
        commit: String,
        path: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        section: Option<String>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        line_start: Option<u32>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        line_end: Option<u32>,
    },
    External {
        external_id: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        version: Option<String>,
        url: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        section: Option<String>,
    },
}

/// Tarih alanları bilerek ayrı tutulur (RFC 3339 metin).
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct SourceDates {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub published_at: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub source_updated_at: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub discovered_at: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub admitted_at: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reviewed_at: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Citation {
    pub source_id: SourceId,
    pub work_id: WorkId,
    pub revision_id: RevisionId,
    pub locator: Locator,
    pub license: String,
    pub attribution: String,
    pub dates: SourceDates,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResultItem {
    pub work_id: WorkId,
    pub kind: WorkKind,
    pub title: String,
    pub snippet: String,
    pub score: u32,
    pub review_state: ReviewState,
    pub citations: Vec<Citation>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SourceCoverage {
    pub source_id: SourceId,
    pub display_name: String,
    pub freshness: Freshness,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub last_successful_refresh: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Coverage {
    pub published_watermark: String,
    pub sources: Vec<SourceCoverage>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResponseEnvelope {
    pub schema_version: String,
    pub status: Status,
    pub query: String,
    pub results: Vec<ResultItem>,
    pub coverage: Coverage,
    pub warnings: Vec<String>,
}
