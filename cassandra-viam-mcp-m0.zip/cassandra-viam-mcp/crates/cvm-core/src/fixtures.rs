//! Sentetik fixture korpusu (dahili belgeler, sürümler, izin sınırları).

use std::collections::HashSet;

use serde::Deserialize;

use crate::envelope::{Freshness, Locator, ReviewState, SourceDates, Visibility, WorkKind};
use crate::ids::{RevisionId, SourceId, WorkId};

#[derive(Debug, Clone, Deserialize)]
pub struct SourceRecord {
    pub id: SourceId,
    pub display_name: String,
    pub license: String,
    pub attribution: String,
    pub freshness: Freshness,
    #[serde(default)]
    pub last_successful_refresh: Option<String>,
    pub visibility: Visibility,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ItemRecord {
    pub work_id: WorkId,
    pub revision_id: RevisionId,
    pub source_id: SourceId,
    pub kind: WorkKind,
    pub title: String,
    pub content: String,
    /// Aynı work'ün en güncel (yayında görünen) revision'ı mı?
    pub current: bool,
    pub review_state: ReviewState,
    pub visibility: Visibility,
    pub locator: Locator,
    #[serde(default)]
    pub dates: SourceDates,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Corpus {
    pub fixture_version: String,
    pub published_watermark: String,
    pub sources: Vec<SourceRecord>,
    pub items: Vec<ItemRecord>,
}

impl Corpus {
    /// Binary'ye gömülü M0 korpusu; bütünlük doğrulaması başarısızsa hata döner.
    pub fn load_embedded() -> Result<Self, String> {
        Self::from_json(include_str!("../../../fixtures/m0/corpus.json"))
    }

    pub fn from_json(json: &str) -> Result<Self, String> {
        let corpus: Corpus =
            serde_json::from_str(json).map_err(|e| format!("corpus.json: {e}"))?;
        let problems = corpus.integrity_problems();
        if problems.is_empty() {
            Ok(corpus)
        } else {
            Err(problems.join("; "))
        }
    }

    pub fn source(&self, id: &SourceId) -> Option<&SourceRecord> {
        self.sources.iter().find(|s| &s.id == id)
    }

    pub fn integrity_problems(&self) -> Vec<String> {
        let mut problems = Vec::new();

        for item in &self.items {
            let expected = RevisionId::from_content(&item.work_id, item.content.as_bytes());
            if expected != item.revision_id {
                problems.push(format!(
                    "{}: revision_id does not match content digest (expected {expected})",
                    item.revision_id
                ));
            }
            if item.work_id.source_slug() != item.source_id.slug() {
                problems.push(format!(
                    "{}: work id does not belong to source {}",
                    item.work_id, item.source_id
                ));
            }
            match self.source(&item.source_id) {
                None => problems.push(format!(
                    "{}: unknown source {}",
                    item.work_id, item.source_id
                )),
                Some(src) if src.visibility != item.visibility => problems.push(format!(
                    "{}: visibility differs from its source",
                    item.work_id
                )),
                Some(_) => {}
            }
        }

        let mut seen = HashSet::new();
        for item in self.items.iter().filter(|i| i.current) {
            if !seen.insert(&item.work_id) {
                problems.push(format!("{}: more than one current revision", item.work_id));
            }
        }
        problems
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::policy::PathPolicy;

    #[test]
    fn embedded_corpus_is_consistent() {
        let corpus = Corpus::load_embedded().expect("embedded corpus must load");
        assert_eq!(corpus.sources.len(), 3);
        assert_eq!(corpus.items.len(), 6);
    }

    #[test]
    fn tampered_content_breaks_the_digest() {
        let mut corpus = Corpus::load_embedded().unwrap();
        corpus.items[0].content.push_str("tampered");
        assert!(!corpus.integrity_problems().is_empty());
    }

    #[test]
    fn two_revisions_of_one_work_have_distinct_ids_and_one_is_current() {
        let corpus = Corpus::load_embedded().unwrap();
        let rows: Vec<_> = corpus
            .items
            .iter()
            .filter(|i| i.work_id.as_str() == "work:arxiv-synthetic/2699.00001")
            .collect();
        assert_eq!(rows.len(), 2);
        assert_ne!(rows[0].revision_id, rows[1].revision_id);
        assert_eq!(rows.iter().filter(|r| r.current).count(), 1);
    }

    #[test]
    fn internal_paths_pass_onboarding_policy_with_matching_attribution() {
        let corpus = Corpus::load_embedded().unwrap();
        let policy = PathPolicy::embedded().unwrap();
        for item in corpus
            .items
            .iter()
            .filter(|i| i.source_id.as_str() == "src:cassandra-synthetic")
        {
            if let Locator::Git { path, .. } = &item.locator {
                let rule = policy
                    .resolve(path, item.content.len() as u64, false)
                    .unwrap_or_else(|d| panic!("{path}: denied by policy: {d:?}"));
                let src = corpus.source(&item.source_id).unwrap();
                assert_eq!(rule.attribution, src.attribution, "{path}");
                assert_eq!(rule.license, src.license, "{path}");
            }
        }
    }
}
