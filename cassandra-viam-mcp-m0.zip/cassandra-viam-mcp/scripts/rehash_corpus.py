#!/usr/bin/env python3
"""fixtures/m0/corpus.json içindeki revision_id alanlarını içerikten yeniden hesaplar.

Kural (crates/cvm-core/src/ids.rs ile aynı):
  rev:<source-slug>/<work-slug>@<sha256(content)[:16]>
Fixture içeriğini değiştirdikten sonra çalıştır:  python3 scripts/rehash_corpus.py
"""
import hashlib
import json
import pathlib

path = pathlib.Path(__file__).resolve().parent.parent / "fixtures" / "m0" / "corpus.json"
corpus = json.loads(path.read_text(encoding="utf-8"))

for item in corpus["items"]:
    rest = item["work_id"].removeprefix("work:")
    digest = hashlib.sha256(item["content"].encode("utf-8")).hexdigest()[:16]
    item["revision_id"] = f"rev:{rest}@{digest}"

path.write_text(json.dumps(corpus, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(f"rehashed {len(corpus['items'])} items")
