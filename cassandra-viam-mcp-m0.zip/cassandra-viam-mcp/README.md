# Cassandra-Viam-MCP — M0 iskeleti (Uyumluluk ve sözleşmeler)

Milestone Planı'nın **M0 / Faz 0** kısmı. Çıkış kriteri: *sabitlenmiş tek bir Rust MCP süreci,
hedef istemcide bir fixture sorgusunu şemaya uygun atıfla yanıtlıyor.*

> **Durum:** Bu kod yazıldığı ortamda derlenip çalıştırılamadı (Rust araç zinciri ve ağ yoktu).
> Fixture verisi ve arama beklentileri Python'da doğrulandı; Rust tarafı ilk `cargo test` ile
> doğrulanmalıdır. Repo'daki `ARCHITECTURE.md` / `docs/specification.md` okunamadı, bu yüzden
> yanıt zarfı, ID kuralları ve izleme kataloğu **plandan çıkarılmış önerilerdir**; spec ile
> karşılaştırıp dondurun.

## Yapı

```
crates/cvm-core   Alan çekirdeği (SDK'dan bağımsız)
  ids.rs          SourceId / WorkId / RevisionId (içerik özetinden değişmez revision ID)
  envelope.rs     v1 yanıt zarfı: Status, Locator, Citation, Coverage, tarih alanları ayrı
  fixtures.rs     Sentetik korpus + bütünlük kontrolü (digest, kaynak, görünürlük)
  policy.rs       Path allowlist + atıf/lisans eşlemesi (symlink, .git, traversal, boyut reddi)
  search.rs       Kapsamlı arama (scope eşleştirmeden ÖNCE uygulanır)
  validate.rs     Zarf sözleşmesi doğrulayıcı (atıfsız sonuç istemciye gitmez)
  catalog.rs      İzleme kataloğu ve R1–R8 eşlemesi için kapı testleri
crates/cvm-mcp    MCP stdio adaptörü (rmcp'ye bağlı tek yer) + uçtan uca test
fixtures/m0       corpus.json, path_policy.json, watch_topics.json, requirements.json
scripts           rehash_corpus.py (fixture revision ID'lerini yeniden hesaplar)
```

## Çalıştırma

```bash
cargo fmt --all
cargo test --workspace          # ilk çalıştırma Cargo.lock üretir → commit'le
cargo build --release
npx @modelcontextprotocol/inspector --cli ./target/release/cvm-mcp --method tools/list
npx @modelcontextprotocol/inspector --cli ./target/release/cvm-mcp \
  --method tools/call --tool-name search_knowledge --tool-arg query="hypothesis 027"

# özel proje kapsamıyla (M7'ye kadar ortam değişkeni; araç argümanı değildir)
CVM_SCOPE_PROJECT=proj-alpha ./target/release/cvm-mcp
```

## M0 görev durumu

| Görev | Durum |
|---|---|
| Rust toolchain + rmcp sürümünü sabitle | `rust-toolchain.toml`, `rmcp = "=3.8.0"` — **sürümü crates.io'dan doğrula** |
| İstemcilerin MCP protokol sürümlerini kaydet | **Elle**: Codex / Claude / Gemini sürümlerini bir tabloya yaz |
| `server/discover` + eski initialize testleri | Eski akış: `tests/stdio_handshake.rs`. `server/discover` için fixture **eklenmeli** (tel formatı doğrulanmadı) |
| Onboarding commit envanteri, allowlist, atıf eşlemesi | Veri + kurallar: `path_policy.json`, `policy.rs`. Gerçek repo envanteri **elle** |
| Sentetik fixture'lar | `corpus.json`: dahili zincir (Hypothesis 027 → Stage 62 → ADR 0019), v1→v2 preprint, proje-özel not |
| v1 zarf, ID kuralları, lisans politikası | Zarf + ID: kodda. Lisans politikası: kaynak başına `license` / `attribution` alanı; **politika metni** spec'ten |
| İzleme konusu başına ≥2 soru, ≥1 dahili-harici | `watch_topics.json` **PLACEHOLDER** (tek konu); kapı testi hazır |
| R1–R8 → fixture/operasyonel kontrol | `requirements.json` + test (R4–R8 henüz `planned`) |

## Bilinçli sınırlar

* Arama basit terim örtüşmesidir; M1'de FTS5 ile değişir, zarf ve scope kuralları aynı kalır.
* Cursor, `as_of`, `get_item`, `get_source_status` M3'tedir.
* Sonraki adım **M1**: `rusqlite` migration'ları, Source/SyncRun/Work/SourceRevision/Publication
  tabloları, değişmez revision'lar, FTS5 projeksiyonu.
